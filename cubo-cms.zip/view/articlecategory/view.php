<h1><?php echo $this->_data->title; ?></h1>
<?php echo $this->_data->html; ?>