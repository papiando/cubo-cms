<?php
defined('__CUBO__') || new \Exception("No use starting this code without an include");
?><h1 itemProp="name headline"><?php echo $this->_data->title; ?></h1>