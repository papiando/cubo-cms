<?php
defined('__CUBO__') || new \Exception("No use starting this code without an include");
?><?php echo $this->_data->html; ?>