<?php
/**************************************************************************************************************
 Class Image
			The Image class contains all images uploaded to the database.
 **************************************************************************************************************/
namespace Cubo;

defined('__CUBO__') || new \Exception("No use starting a class without an include");

class Image extends Model {
}
?>