<?php
/**************************************************************************************************************
 Class Article
			The Article class contains all articles.
 **************************************************************************************************************/
namespace Cubo;

defined('__CUBO__') || new \Exception("No use starting a class without an include");

class Article extends Model {
}
?>