<article>
	<h2 style="text-decoration: underline;"><?php echo $this->_data->title; ?></h2>
	<?php echo $this->_data->html; ?>
</article>